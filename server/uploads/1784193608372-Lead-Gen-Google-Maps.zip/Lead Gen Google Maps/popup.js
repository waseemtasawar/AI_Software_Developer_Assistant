const els = {
  start: document.getElementById("startBtn"),
  pause: document.getElementById("pauseBtn"),
  download: document.getElementById("downloadBtn"),
  clear: document.getElementById("clearBtn"),
  save: document.getElementById("saveSettingsBtn"),
  pill: document.getElementById("statusPill"),
  stage: document.getElementById("stageText"),
  query: document.getElementById("queryText"),
  bar: document.getElementById("progressBar"),
  found: document.getElementById("countFound"),
  websites: document.getElementById("countWebsites"),
  enriched: document.getElementById("countEnriched"),
  emails: document.getElementById("countEmails"),
  phones: document.getElementById("countPhones"),
  quality: document.getElementById("qualityScore"),
  message: document.getElementById("message"),
  preview: document.getElementById("leadPreview"),
  scrollDelayValue: document.getElementById("scrollDelayValue"),
  inputs: {
    detailScan: document.getElementById("detailScan"),
    websiteEnrichment: document.getElementById("websiteEnrichment"),
    includeSocials: document.getElementById("includeSocials"),
    resultLimit: document.getElementById("resultLimit"),
    detailLimit: document.getElementById("detailLimit"),
    crawlPages: document.getElementById("crawlPages"),
    concurrency: document.getElementById("concurrency"),
    scrollDelay: document.getElementById("scrollDelay")
  }
};

let lastState = {};

async function send(type, payload = {}) {
  return chrome.runtime.sendMessage({ type, ...payload });
}

function readSettings() {
  return {
    detailScan: els.inputs.detailScan.checked,
    websiteEnrichment: els.inputs.websiteEnrichment.checked,
    includeSocials: els.inputs.includeSocials.checked,
    resultLimit: Number(els.inputs.resultLimit.value || 0),
    detailLimit: Number(els.inputs.detailLimit.value || 0),
    crawlPages: Number(els.inputs.crawlPages.value || 14),
    concurrency: Number(els.inputs.concurrency.value || 6),
    scrollDelay: Number(els.inputs.scrollDelay.value || 320)
  };
}

function writeSettings(settings = {}) {
  els.inputs.detailScan.checked = settings.detailScan !== false;
  els.inputs.websiteEnrichment.checked = settings.websiteEnrichment !== false;
  els.inputs.includeSocials.checked = settings.includeSocials !== false;
  els.inputs.resultLimit.value = settings.resultLimit ?? 0;
  els.inputs.detailLimit.value = settings.detailLimit ?? 0;
  els.inputs.crawlPages.value = settings.crawlPages ?? 14;
  els.inputs.concurrency.value = settings.concurrency ?? 6;
  els.inputs.scrollDelay.value = settings.scrollDelay ?? 320;
  els.scrollDelayValue.textContent = `${els.inputs.scrollDelay.value}ms`;
}

function render(state = {}) {
  lastState = state;
  const status = state.status || "idle";
  const total = Number(state.total || state.leads?.length || 0);
  const enriched = Number(state.enriched || 0);
  const progress = total ? Math.min(100, Math.round((enriched / total) * 100)) : status === "running" ? 12 : 0;

  els.pill.className = `pill ${status}`;
  els.pill.textContent = status;
  els.stage.textContent = formatStage(state.stage || "ready");
  els.query.textContent = state.query || "Open Google Maps and search a query.";
  els.bar.style.width = `${progress}%`;
  els.found.textContent = total;
  els.websites.textContent = state.websiteCount || 0;
  els.enriched.textContent = enriched;
  els.emails.textContent = state.emailCount || 0;
  els.phones.textContent = state.phoneCount || 0;
  els.quality.textContent = `${state.qualityScore || 0}%`;
  els.message.textContent = state.message || "Ready to collect business leads from the current Maps results page.";

  if (state.settings) writeSettings(state.settings);
  renderPreview(state.leads || []);

  els.start.disabled = status === "running";
  els.pause.disabled = status !== "running";
  els.download.disabled = total === 0;
}

function renderPreview(leads) {
  const sample = leads.slice(0, 3);
  if (!sample.length) {
    els.preview.innerHTML = "<p>No leads captured yet.</p>";
    return;
  }

  els.preview.innerHTML = sample.map((lead) => `
    <article>
      <strong>${escapeHtml(lead.name || "Unnamed business")}</strong>
      <span>${escapeHtml(lead.address || lead.category || "Address pending")}</span>
      <small>${escapeHtml([lead.websiteEmails, lead.mapsPhone || lead.websitePhones].filter(Boolean).join(" | ") || "Contacts pending")}</small>
    </article>
  `).join("");
}

function formatStage(stage) {
  const labels = {
    ready: "Ready",
    scrolling: "Maps scrolling",
    details: "Detail scan",
    website: "Website enrichment",
    complete: "Complete",
    paused: "Paused",
    error: "Needs attention"
  };
  return labels[stage] || stage;
}

async function refresh() {
  try {
    render(await send("GET_STATE"));
  } catch (error) {
    els.message.textContent = error.message || "Could not read extension state.";
  }
}

els.start.addEventListener("click", async () => {
  els.message.textContent = "Starting advanced lead engine...";
  render(await send("START_SCRAPE", { settings: readSettings() }));
});

els.pause.addEventListener("click", async () => {
  render(await send("PAUSE_SCRAPE"));
});

els.download.addEventListener("click", async () => {
  render(await send("DOWNLOAD_EXCEL"));
});

els.clear.addEventListener("click", async () => {
  render(await send("CLEAR_RESULTS"));
});

els.save.addEventListener("click", async () => {
  render(await send("SAVE_SETTINGS", { settings: readSettings() }));
});

els.inputs.scrollDelay.addEventListener("input", () => {
  els.scrollDelayValue.textContent = `${els.inputs.scrollDelay.value}ms`;
});

Object.values(els.inputs).forEach((input) => {
  input.addEventListener("change", () => {
    send("SAVE_SETTINGS", { settings: readSettings() }).then(render).catch(() => {});
  });
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "STATE_UPDATED") render(message.state);
});

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

refresh();
setInterval(refresh, 900);
