# SUF Reveals Lead Generator

A professional Chrome Manifest V3 extension for Google Maps lead generation with a glass-effect dashboard, advanced extraction controls, background website enrichment, and styled Excel export.

## What It Does

- Scrolls the active Google Maps results list until the end is reached or your result limit is met.
- Captures business name, category, address, rating, review count, Google Maps URL, website, and phone fields when available.
- Optional Maps detail scan improves phone, website, and address quality from each business detail page.
- Optional website enrichment crawls each business website in the background without opening visible website tabs.
- Extracts website emails, website phone numbers, and social links separately from the Google Maps phone number.
- Shows live counts for leads, websites, emails, phones, enrichment progress, and lead quality.
- Lets you pause mid-run and export whatever has already been captured.
- Exports a styled Excel-compatible `.xls` workbook with dashboard metrics, colored headers, filters, frozen rows, alternating row styling, and lead quality scores.

## Advanced Controls

- `Maps detail scan`: improves data quality by opening Maps business detail views in the same Maps tab.
- `Website enrichment`: crawls business websites for contact data.
- `Social links`: collects Facebook, Instagram, LinkedIn, X, and YouTube URLs from websites.
- `Result limit`: caps how many Maps leads to collect. Use `0` for all loaded results.
- `Detail limit`: caps how many leads receive Maps detail scanning. Use `0` to scan all collected leads.
- `Crawl pages/site`: controls how many same-domain pages are checked per business website.
- `Parallel workers`: controls background website crawling speed.
- `Scroll delay`: balances speed against Google Maps rendering reliability.

## Install Locally

1. Open Chrome and go to `chrome://extensions`.
2. Enable `Developer mode`.
3. Click `Load unpacked`.
4. Select this folder:

   `/Users/muhammadsufian/Documents/Lead Gen Google Maps`

## Use

1. Open Google Maps in Chrome.
2. Search a query such as `Restaurants in USA`.
3. Open the extension popup and set the advanced controls.
4. Click `Start`.
5. Click `Pause` any time to stop and download the current results.
6. Click `Export` to save the Excel-compatible lead sheet.

## Important Reality Notes

Google Maps and business websites frequently change their markup and access controls. Some websites block background fetching, hide contact details behind JavaScript, or publish no email address. Full website crawling for many results cannot reliably finish in only a few seconds, so the extension uses configurable concurrency and page limits to balance speed and quality.
