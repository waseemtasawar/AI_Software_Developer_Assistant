const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

let stopRequested = false;

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "SCRAPE_MAPS") {
    stopRequested = false;
    scrapeMapsResults(message.settings || {}).then(sendResponse);
    return true;
  }

  if (message.type === "STOP_MAPS_SCRAPE") {
    stopRequested = true;
    sendResponse({ ok: true });
  }

  return false;
});

async function scrapeMapsResults(settings) {
  const query = getSearchQuery();
  const scroller = findResultsScroller();
  const seen = new Map();
  const limit = Number(settings.resultLimit || 0);
  const delay = Number(settings.scrollDelay || 360);

  if (!scroller) {
    return { ok: false, query, leads: [], error: "Search results list was not found. Search Google Maps first." };
  }

  await report("scrolling", "Reading visible Google Maps cards...", { query, found: 0 });

  let stableRounds = 0;
  let lastSize = 0;

  for (let round = 0; round < 240 && !stopRequested; round += 1) {
    collectVisibleCards(seen);
    await report("scrolling", `Scrolling results... ${seen.size} cards captured`, { query, found: seen.size });

    if (limit && seen.size >= limit) break;
    if (hasEndOfList()) break;

    stableRounds = seen.size === lastSize ? stableRounds + 1 : 0;
    lastSize = seen.size;
    if (stableRounds >= 10) break;

    scroller.scrollBy({ top: Math.max(620, scroller.clientHeight * 0.92), behavior: "instant" });
    await sleep(delay);
  }

  collectVisibleCards(seen);
  let leads = Array.from(seen.values()).slice(0, limit || undefined).map(cleanLead);

  if (settings.detailScan !== false && leads.length && !stopRequested) {
    leads = await enrichFromMapsDetails(leads, settings);
  }

  return {
    ok: true,
    query,
    stopped: stopRequested,
    leads: leads.map(cleanLead)
  };
}

function collectVisibleCards(seen) {
  extractVisibleCards().forEach((lead) => {
    const key = normalizeKey(lead);
    if (key) seen.set(key, { ...seen.get(key), ...lead });
  });
}

function extractVisibleCards() {
  const anchors = Array.from(document.querySelectorAll("a[href*='/maps/place/'], a.hfpxzc"));
  const cards = anchors
    .map((anchor) => anchor.closest("[role='article']") || anchor.closest(".Nv2PK") || anchor.closest(".THOPZb") || anchor.parentElement)
    .filter(Boolean);

  return cards.map((card) => extractCard(card)).filter((lead) => lead.name && lead.mapsUrl);
}

function extractCard(card) {
  const text = compact(card.innerText);
  const lines = text.split("\n").map((line) => line.trim()).filter(Boolean);
  const placeLink = card.querySelector("a[href*='/maps/place/'], a.hfpxzc")?.href || "";
  const name = getName(card, lines);
  const rating = getRating(card, text);
  const reviewCount = getReviewCount(card, text);
  const website = getActionUrl(card, "Website");
  const mapsPhone = findPhone(lines.join(" "));
  const address = findAddress(lines, name);
  const category = findCategory(lines, address, name);

  return {
    name,
    category,
    address,
    website,
    mapsUrl: placeLink,
    mapsPhone,
    rating,
    reviewCount,
    source: location.href,
    confidence: scoreLead({ name, address, website, mapsPhone, rating, reviewCount })
  };
}

async function enrichFromMapsDetails(leads, settings) {
  const originalUrl = location.href;
  const maxDetails = Number(settings.detailLimit || 0) || leads.length;

  for (let index = 0; index < leads.length && index < maxDetails && !stopRequested; index += 1) {
    const lead = leads[index];
    await report("details", `Opening Maps details ${index + 1} of ${Math.min(leads.length, maxDetails)}...`, {
      found: leads.length,
      detailIndex: index + 1
    });

    const opened = await openMapsDetail(lead.mapsUrl);
    if (!opened) continue;

    const details = extractDetailsPanel();
    leads[index] = cleanLead({
      ...lead,
      ...emptySafe(details),
      confidence: scoreLead({ ...lead, ...details })
    });
  }

  if (location.href !== originalUrl) {
    history.pushState(null, "", originalUrl);
    window.dispatchEvent(new PopStateEvent("popstate"));
    await sleep(600);
  }

  return leads;
}

async function openMapsDetail(url) {
  const currentTitle = document.querySelector("h1.DUwDvf, h1")?.textContent || "";
  history.pushState(null, "", url);
  window.dispatchEvent(new PopStateEvent("popstate"));

  for (let i = 0; i < 30 && !stopRequested; i += 1) {
    await sleep(250);
    const title = document.querySelector("h1.DUwDvf, h1")?.textContent || "";
    if (title && title !== currentTitle) return true;
  }

  return Boolean(document.querySelector("h1.DUwDvf, h1"));
}

function extractDetailsPanel() {
  const panel = document.querySelector("[role='main']") || document.body;
  const text = compact(panel.innerText);
  const lines = text.split("\n").map((line) => line.trim()).filter(Boolean);
  const website = getActionUrl(panel, "Website") || findWebsiteFromButtons(panel);
  const phone = getButtonValue(panel, "Phone") || findPhone(text);
  const address = getButtonValue(panel, "Address") || findAddress(lines);
  const rating = getRating(panel, text);
  const reviewCount = getReviewCount(panel, text);
  const name = document.querySelector("h1.DUwDvf, h1")?.textContent?.trim() || "";
  const category = getCategoryFromDetails(panel, lines);

  return {
    name,
    category,
    address,
    website,
    mapsPhone: phone,
    rating,
    reviewCount
  };
}

function getSearchQuery() {
  const input = document.querySelector("#searchboxinput");
  return input?.value?.trim() || document.title.replace(" - Google Maps", "").trim();
}

function findResultsScroller() {
  const candidates = Array.from(document.querySelectorAll("div[role='feed'], div.m6QErb[tabindex='-1'], div[aria-label][role='main']"));
  return candidates.find((el) => el.scrollHeight > el.clientHeight + 300 && el.querySelector("a[href*='/maps/place/'], a.hfpxzc")) ||
    candidates.find((el) => el.scrollHeight > el.clientHeight + 300) ||
    document.scrollingElement;
}

function hasEndOfList() {
  return /You've reached the end of the list\.?/i.test(document.body.innerText);
}

function getName(card, lines) {
  const named = card.querySelector(".qBF1Pd, .fontHeadlineSmall")?.textContent?.trim();
  if (named) return named;
  const aria = card.querySelector("a.hfpxzc")?.getAttribute("aria-label")?.trim();
  if (aria) return aria;
  return lines.find((line) => line.length > 1 && !/sponsored|closed|open|stars|\(\d|website|directions/i.test(line)) || "";
}

function getRating(node, text) {
  const aria = node.querySelector("[aria-label*='stars']")?.getAttribute("aria-label") || "";
  const ariaMatch = aria.match(/([1-5](?:\.\d)?)/);
  if (ariaMatch) return ariaMatch[1];
  const textMatch = text.match(/\b([1-5](?:\.\d)?)\s*(?:stars?)?\b/);
  return textMatch ? textMatch[1] : "";
}

function getReviewCount(node, text) {
  const aria = node.querySelector("[aria-label*='reviews']")?.getAttribute("aria-label") || "";
  const ariaMatch = aria.match(/([\d,]+)\s+reviews?/i);
  if (ariaMatch) return ariaMatch[1].replace(/,/g, "");
  const textMatch = text.match(/\(([\d,]+)\)/);
  return textMatch ? textMatch[1].replace(/,/g, "") : "";
}

function getActionUrl(node, label) {
  const lower = label.toLowerCase();
  const anchor = Array.from(node.querySelectorAll("a[href]")).find((a) => {
    const aria = (a.getAttribute("aria-label") || a.textContent || "").toLowerCase();
    return aria.includes(lower) && !a.href.includes("google.com/maps");
  });
  return anchor?.href || "";
}

function findWebsiteFromButtons(node) {
  return Array.from(node.querySelectorAll("a[href]"))
    .map((a) => a.href)
    .find((href) => href && !/google\./i.test(href) && /^https?:/i.test(href)) || "";
}

function getButtonValue(node, item) {
  const selector = item === "Address" ? "[data-item-id='address']" : "[data-item-id^='phone:tel']";
  const el = node.querySelector(selector);
  const aria = el?.getAttribute("aria-label") || "";
  return aria.replace(new RegExp(`^${item}:?\\s*`, "i"), "").replace(/,?\\s*Copy.*$/i, "").trim();
}

function findAddress(lines, name = "") {
  const cleaned = lines.map((line) => line.replace(/\ue934/g, "·").trim());
  const withBullets = cleaned.find((line) => line.includes("·") && /\d/.test(line));
  if (withBullets) return withBullets.split("·").pop().trim();

  return cleaned.find((line) =>
    line !== name &&
    /\d/.test(line) &&
    /\b(st|street|ave|avenue|road|rd|blvd|drive|dr|lane|ln|way|court|ct|suite|unit|plaza|pkwy|parkway|hwy|highway|united states|usa|canada|pakistan|uk)\b/i.test(line)
  ) || "";
}

function findCategory(lines, address, name) {
  const line = lines.map((item) => item.replace(/\ue934/g, "·")).find((item) => item.includes("·") && item !== address && item !== name);
  return line ? line.split("·")[0].trim() : "";
}

function getCategoryFromDetails(node, lines) {
  const button = node.querySelector("button[jsaction*='category'], button.DkEaL");
  if (button?.textContent?.trim()) return button.textContent.trim();
  return lines.find((line) => /restaurant|store|agency|service|hotel|clinic|company|bar|cafe|shop/i.test(line)) || "";
}

function findPhone(text) {
  const match = text.match(/(?:\+\d{1,3}[\s().-]?)?(?:\(?\d{2,4}\)?[\s().-]?){2,5}\d{3,4}/);
  return match ? match[0].replace(/\s+/g, " ").trim() : "";
}

function normalizeKey(lead) {
  return [lead.name, lead.address || lead.mapsUrl].filter(Boolean).join("|").toLowerCase();
}

function cleanLead(lead) {
  return Object.fromEntries(Object.entries(lead).map(([key, value]) => [key, typeof value === "string" ? compact(value) : value]));
}

function emptySafe(details) {
  return Object.fromEntries(Object.entries(details).filter(([, value]) => value !== "" && value != null));
}

function scoreLead(lead) {
  let score = 0;
  if (lead.name) score += 20;
  if (lead.address) score += 20;
  if (lead.website) score += 20;
  if (lead.mapsPhone) score += 18;
  if (lead.rating) score += 10;
  if (lead.reviewCount) score += 7;
  if (lead.category) score += 5;
  return Math.min(100, score);
}

function compact(value) {
  return (value || "").replace(/\s+\n/g, "\n").replace(/\n\s+/g, "\n").replace(/[ \t]+/g, " ").trim();
}

async function report(stage, message, extra = {}) {
  chrome.runtime.sendMessage({ type: "SCRAPE_PROGRESS", stage, message, ...extra }).catch(() => {});
}
