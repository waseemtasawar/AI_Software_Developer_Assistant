const DEFAULT_SETTINGS = {
  detailScan: true,
  websiteEnrichment: true,
  resultLimit: 0,
  detailLimit: 0,
  scrollDelay: 320,
  crawlPages: 14,
  concurrency: 6,
  includeSocials: true,
  exportFormat: "xls"
};

const DEFAULT_STATE = {
  status: "idle",
  stage: "ready",
  query: "",
  message: "Open Google Maps, run a search, then start the engine.",
  leads: [],
  total: 0,
  enriched: 0,
  detailIndex: 0,
  emailCount: 0,
  phoneCount: 0,
  websiteCount: 0,
  qualityScore: 0,
  settings: DEFAULT_SETTINGS,
  startedAt: null,
  finishedAt: null
};

let state = { ...DEFAULT_STATE };
let pauseRequested = false;

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get(["settings", "state"]);
  state = { ...state, ...(stored.state || {}), settings: { ...DEFAULT_SETTINGS, ...(stored.settings || {}) } };
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message).then(sendResponse);
  return true;
});

async function handleMessage(message) {
  if (message.type === "GET_STATE") return hydrateState();
  if (message.type === "SAVE_SETTINGS") return saveSettings(message.settings || {});
  if (message.type === "START_SCRAPE") return startScrape(message.settings || {});
  if (message.type === "PAUSE_SCRAPE") return pauseScrape();
  if (message.type === "CLEAR_RESULTS") return clearResults();
  if (message.type === "DOWNLOAD_EXCEL") return downloadExcel();
  if (message.type === "SCRAPE_PROGRESS") return handleProgress(message);
  return state;
}

async function hydrateState() {
  const stored = await chrome.storage.local.get(["settings", "state"]);
  state = {
    ...state,
    ...(stored.state || {}),
    settings: { ...DEFAULT_SETTINGS, ...(stored.settings || {}), ...(state.settings || {}) }
  };
  return state;
}

async function saveSettings(settings) {
  state.settings = normalizeSettings({ ...state.settings, ...settings });
  await chrome.storage.local.set({ settings: state.settings });
  return setState({ settings: state.settings, message: "Advanced settings saved." });
}

async function startScrape(incomingSettings = {}) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab.url?.includes("google.com/maps")) {
    return setState({
      status: "idle",
      stage: "ready",
      message: "Open a Google Maps results page, search your query, then press Start."
    });
  }

  pauseRequested = false;
  const settings = normalizeSettings({ ...state.settings, ...incomingSettings });
  await chrome.storage.local.set({ settings });

  setState({
    ...DEFAULT_STATE,
    settings,
    status: "running",
    stage: "scrolling",
    startedAt: new Date().toISOString(),
    message: "Scanning Google Maps results..."
  });

  try {
    const response = await chrome.tabs.sendMessage(tab.id, { type: "SCRAPE_MAPS", settings });
    if (!response?.ok) {
      return setState({ status: "idle", stage: "error", message: response?.error || "Google Maps scraping failed." });
    }

    const leads = dedupeLeads(response.leads || []);
    setState({
      status: pauseRequested || response.stopped ? "paused" : "running",
      stage: "website",
      query: response.query || "",
      leads,
      total: leads.length,
      ...summarize(leads),
      message: leads.length ? "Maps data captured. Website enrichment is running..." : "No leads found on this page."
    });

    if (!pauseRequested && leads.length && settings.websiteEnrichment) {
      await enrichLeads(settings);
    } else {
      setState({
        status: pauseRequested || response.stopped ? "paused" : "done",
        stage: pauseRequested ? "paused" : "complete",
        finishedAt: new Date().toISOString(),
        message: leads.length ? "Maps scan finished. Download is ready." : "No leads found."
      });
    }

    return state;
  } catch (error) {
    return setState({ status: "idle", stage: "error", message: error.message || "Could not communicate with Google Maps tab." });
  }
}

async function pauseScrape() {
  pauseRequested = true;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id) chrome.tabs.sendMessage(tab.id, { type: "STOP_MAPS_SCRAPE" }).catch(() => {});
  return setState({ status: "paused", stage: "paused", message: "Paused. Current results are ready to download." });
}

async function clearResults() {
  pauseRequested = false;
  await chrome.storage.local.remove("state");
  return setState({ ...DEFAULT_STATE, settings: state.settings, message: "Results cleared. Ready for a fresh run." });
}

function handleProgress(message) {
  return setState({
    stage: message.stage || state.stage,
    message: message.message || state.message,
    query: message.query || state.query,
    total: message.found || state.total,
    detailIndex: message.detailIndex || state.detailIndex
  });
}

async function enrichLeads(settings) {
  let cursor = 0;
  const concurrency = clamp(settings.concurrency, 1, 12);

  async function worker() {
    while (cursor < state.leads.length && !pauseRequested) {
      const leadIndex = cursor;
      cursor += 1;
      let lead = state.leads[leadIndex];
      if ((settings.detailScan !== false) && lead.mapsUrl && (!lead.website || !lead.mapsPhone)) {
        lead = cleanLead({ ...lead, ...(await enrichFromMapsUrl(lead.mapsUrl)) });
      }
      const enriched = lead.website ? await crawlWebsite(lead.website, settings) : {};
      state.leads[leadIndex] = cleanLead({
        ...lead,
        ...enriched,
        confidence: scoreLead({ ...lead, ...enriched })
      });

      const summary = summarize(state.leads);
      setState({
        leads: state.leads,
        enriched: Math.min(state.enriched + 1, state.total),
        ...summary,
        message: `Website enrichment ${Math.min(state.enriched + 1, state.total)} of ${state.total}...`
      });
    }
  }

  await Promise.all(Array.from({ length: concurrency }, worker));
  setState({
    status: pauseRequested ? "paused" : "done",
    stage: pauseRequested ? "paused" : "complete",
    finishedAt: new Date().toISOString(),
    message: pauseRequested ? "Paused. Download is ready with current results." : "Finished. Download your enriched Excel workbook."
  });
}

async function enrichFromMapsUrl(mapsUrl) {
  const html = await fetchText(mapsUrl);
  if (!html) return {};

  const website = findExternalWebsite(html);
  const phones = extractPhones(html);
  return cleanLead({
    website,
    mapsPhone: phones[0] || ""
  });
}

async function crawlWebsite(startUrl, settings) {
  const root = safeUrl(startUrl);
  if (!root) return {};

  const maxPages = clamp(settings.crawlPages, 1, 40);
  const queue = [root.href];
  const visited = new Set();
  const emails = new Set();
  const phones = new Set();
  const socials = new Set();

  while (queue.length && visited.size < maxPages && !pauseRequested) {
    const url = queue.shift();
    if (!url || visited.has(url)) continue;
    visited.add(url);

    const html = await fetchText(url);
    if (!html) continue;

    extractEmails(html).forEach((email) => emails.add(email));
    extractPhones(html).forEach((phone) => phones.add(phone));
    if (settings.includeSocials) extractSocials(html).forEach((social) => socials.add(social));

    discoverLinks(html, root).forEach((link) => {
      if (!visited.has(link) && !queue.includes(link) && queue.length < maxPages * 3) queue.push(link);
    });
  }

  return {
    websiteEmails: Array.from(emails).join(", "),
    websitePhones: Array.from(phones).join(", "),
    socialLinks: Array.from(socials).join(", "),
    pagesScanned: visited.size
  };
}

function findExternalWebsite(text) {
  const candidates = [...text.matchAll(/https?:\\?\/\\?\/[^"'<>\\\s)]+/gi)]
    .map((m) => m[0].replace(/\\\//g, "/").replace(/[\\.,;]+$/, ""))
    .filter((url) => {
      try {
        const parsed = new URL(url);
        return /^https?:$/.test(parsed.protocol) &&
          !/google|gstatic|googleusercontent|schema\.org|w3\.org|ggpht|doubleclick/i.test(parsed.hostname);
      } catch {
        return false;
      }
    });

  return candidates.find((url) => !/facebook|instagram|twitter|youtube|linkedin/i.test(url)) || candidates[0] || "";
}

async function fetchText(url) {
  try {
    const response = await fetch(url, { redirect: "follow", credentials: "omit", cache: "force-cache" });
    const type = response.headers.get("content-type") || "";
    if (!response.ok || !/text\/html|application\/xhtml\+xml/i.test(type)) return "";
    return await response.text();
  } catch {
    return "";
  }
}

function discoverLinks(html, root) {
  const important = /contact|about|team|staff|location|locations|privacy|support|reservation|booking|menu|service/i;
  const links = [];
  const hrefRegex = /href=["']([^"'#]+)["']/gi;
  let match;

  while ((match = hrefRegex.exec(html))) {
    const url = safeUrl(match[1], root.href);
    if (!url || url.hostname.replace(/^www\./, "") !== root.hostname.replace(/^www\./, "")) continue;
    url.hash = "";
    if (important.test(url.pathname) || links.length < 6) links.push(url.href);
  }

  return [...new Set(links)].slice(0, 24);
}

function extractEmails(text) {
  return [...text.matchAll(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi)]
    .map((m) => m[0].toLowerCase())
    .filter((email) => !/\.(png|jpg|jpeg|gif|webp|svg|css|js)$/i.test(email))
    .slice(0, 20);
}

function extractPhones(text) {
  return [...text.matchAll(/(?:\+\d{1,3}[\s().-]?)?(?:\(?\d{2,4}\)?[\s().-]?){2,5}\d{3,4}/g)]
    .map((m) => m[0].replace(/\s+/g, " ").trim())
    .filter((phone) => {
      const digits = phone.replace(/\D/g, "");
      return digits.length >= 9 && digits.length <= 16 && !/^0+$/.test(digits);
    })
    .slice(0, 12);
}

function extractSocials(text) {
  return [...text.matchAll(/https?:\/\/(?:www\.)?(?:facebook|instagram|linkedin|x|twitter|youtube)\.com\/[^"'<>\s)]+/gi)]
    .map((m) => m[0].replace(/[.,;]+$/, ""))
    .slice(0, 12);
}

async function downloadExcel() {
  if (!state.leads.length) return setState({ message: "No results yet. Start scraping before downloading." });

  const workbook = buildExcelXml(state.leads);
  const url = `data:application/vnd.ms-excel;charset=utf-8,${encodeURIComponent(workbook)}`;
  const filename = `suf-reveals-leads-${new Date().toISOString().slice(0, 10)}.xls`;
  await chrome.downloads.download({ url, filename, saveAs: true });
  return setState({ message: "Excel download started." });
}

function buildExcelXml(leads) {
  const columns = [
    ["name", "Business Name", 190],
    ["category", "Category", 160],
    ["address", "Address", 280],
    ["website", "Website Link", 230],
    ["mapsPhone", "Google Maps Phone", 150],
    ["websitePhones", "Website Phone Numbers", 210],
    ["websiteEmails", "Website Emails", 260],
    ["rating", "Rating Star", 90],
    ["reviewCount", "Number of Reviews", 120],
    ["pagesScanned", "Website Pages Scanned", 120],
    ["socialLinks", "Social Links", 260],
    ["confidence", "Lead Quality", 95],
    ["mapsUrl", "Google Maps URL", 300]
  ];
  const summary = summarize(leads);
  const rows = leads.map((lead) => columns.map(([key]) => xml(lead[key] || "")));

  return `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
 <Styles>
  <Style ss:ID="Title"><Font ss:Bold="1" ss:Size="20" ss:Color="#FFFFFF"/><Interior ss:Color="#102A43" ss:Pattern="Solid"/></Style>
  <Style ss:ID="Metric"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#0F766E" ss:Pattern="Solid"/></Style>
  <Style ss:ID="Header"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#2563EB" ss:Pattern="Solid"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#102A43"/></Borders></Style>
  <Style ss:ID="Cell"><Alignment ss:Vertical="Top" ss:WrapText="1"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#D7E3EA"/></Borders></Style>
  <Style ss:ID="Alt"><Alignment ss:Vertical="Top" ss:WrapText="1"/><Interior ss:Color="#F8FAFC" ss:Pattern="Solid"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#D7E3EA"/></Borders></Style>
 </Styles>
 <Worksheet ss:Name="SUF Reveals Leads">
  <Table>
   ${columns.map(([, , width]) => `<Column ss:Width="${width}"/>`).join("")}
   <Row ss:Height="34"><Cell ss:MergeAcross="${columns.length - 1}" ss:StyleID="Title"><Data ss:Type="String">SUF Reveals Google Maps Lead Generator</Data></Cell></Row>
   <Row>
    <Cell ss:StyleID="Metric"><Data ss:Type="String">Total Leads: ${summary.total}</Data></Cell>
    <Cell ss:StyleID="Metric"><Data ss:Type="String">Websites: ${summary.websiteCount}</Data></Cell>
    <Cell ss:StyleID="Metric"><Data ss:Type="String">Emails: ${summary.emailCount}</Data></Cell>
    <Cell ss:StyleID="Metric"><Data ss:Type="String">Phones: ${summary.phoneCount}</Data></Cell>
    <Cell ss:StyleID="Metric"><Data ss:Type="String">Quality: ${summary.qualityScore}%</Data></Cell>
   </Row>
   <Row>${columns.map(([, label]) => `<Cell ss:StyleID="Header"><Data ss:Type="String">${xml(label)}</Data></Cell>`).join("")}</Row>
   ${rows.map((row, i) => `<Row>${row.map((value) => `<Cell ss:StyleID="${i % 2 ? "Alt" : "Cell"}"><Data ss:Type="String">${value}</Data></Cell>`).join("")}</Row>`).join("")}
  </Table>
  <AutoFilter x:Range="R3C1:R${leads.length + 3}C${columns.length}" xmlns="urn:schemas-microsoft-com:office:excel"/>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"><FreezePanes/><FrozenNoSplit/><SplitHorizontal>3</SplitHorizontal><TopRowBottomPane>3</TopRowBottomPane><ActivePane>2</ActivePane></WorksheetOptions>
 </Worksheet>
</Workbook>`;
}

function normalizeSettings(settings) {
  return {
    detailScan: settings.detailScan !== false,
    websiteEnrichment: settings.websiteEnrichment !== false,
    resultLimit: clamp(settings.resultLimit, 0, 1000),
    detailLimit: clamp(settings.detailLimit, 0, 1000),
    scrollDelay: clamp(settings.scrollDelay, 120, 1200),
    crawlPages: clamp(settings.crawlPages, 1, 40),
    concurrency: clamp(settings.concurrency, 1, 12),
    includeSocials: settings.includeSocials !== false,
    exportFormat: "xls"
  };
}

function dedupeLeads(leads) {
  const seen = new Map();
  leads.forEach((lead) => {
    const key = [lead.name, lead.address || lead.mapsUrl].filter(Boolean).join("|").toLowerCase();
    if (key) seen.set(key, cleanLead({ ...seen.get(key), ...lead }));
  });
  return Array.from(seen.values()).map((lead) => ({ ...lead, confidence: scoreLead(lead) }));
}

function summarize(leads) {
  const total = leads.length;
  const emailCount = leads.reduce((sum, lead) => sum + splitCount(lead.websiteEmails), 0);
  const phoneCount = leads.reduce((sum, lead) => sum + Number(Boolean(lead.mapsPhone)) + splitCount(lead.websitePhones), 0);
  const websiteCount = leads.filter((lead) => lead.website).length;
  const qualityScore = total ? Math.round(leads.reduce((sum, lead) => sum + Number(lead.confidence || scoreLead(lead)), 0) / total) : 0;
  return { total, emailCount, phoneCount, websiteCount, qualityScore };
}

function scoreLead(lead) {
  let score = 0;
  if (lead.name) score += 18;
  if (lead.category) score += 6;
  if (lead.address) score += 18;
  if (lead.website) score += 18;
  if (lead.mapsPhone) score += 14;
  if (lead.websitePhones) score += 10;
  if (lead.websiteEmails) score += 10;
  if (lead.rating) score += 3;
  if (lead.reviewCount) score += 3;
  return Math.min(100, score);
}

function splitCount(value) {
  return value ? String(value).split(",").map((item) => item.trim()).filter(Boolean).length : 0;
}

function safeUrl(value, base) {
  try {
    const url = new URL(value, base);
    if (!/^https?:$/.test(url.protocol)) return null;
    return url;
  } catch {
    return null;
  }
}

function clamp(value, min, max) {
  const number = Number(value);
  if (!Number.isFinite(number)) return min;
  return Math.max(min, Math.min(max, Math.round(number)));
}

function cleanLead(lead) {
  return Object.fromEntries(Object.entries(lead || {}).map(([key, value]) => [key, typeof value === "string" ? compact(value) : value]));
}

function compact(value) {
  return (value || "").replace(/\s+\n/g, "\n").replace(/\n\s+/g, "\n").replace(/[ \t]+/g, " ").trim();
}

function xml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function setState(patch) {
  state = { ...state, ...patch };
  chrome.storage.local.set({ state }).catch(() => {});
  chrome.runtime.sendMessage({ type: "STATE_UPDATED", state }).catch(() => {});
  return state;
}
